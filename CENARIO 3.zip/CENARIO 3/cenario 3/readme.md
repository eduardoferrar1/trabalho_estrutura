CREATE DATABASE escola_cursos;

CREATE TABLE aluno (

    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    telefone VARCHAR(20) NOT NULL

);

CREATE TABLE curso(

    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    carga_horaria INTEGER NOT NULL,
    vagas_totais INTEGER NOT NULL,
    vagas_disponiveis INTEGER NOT NULL

);

CREATE TABLE matricula(

    id SERIAL PRIMARY KEY,

    id_aluno INTEGER NOT NULL,
    id_curso INTEGER NOT NULL,

    data_matricula DATE NOT NULL,
    valor NUMERIC(10,2) NOT NULL CHECK(valor >= 0),

    CONSTRAINT fk_aluno
        FOREIGN KEY(id_aluno)
        REFERENCES aluno(id),

    CONSTRAINT fk_curso
        FOREIGN KEY(id_curso)
        REFERENCES curso(id),

    CONSTRAINT aluno_curso_unico
        UNIQUE(id_aluno,id_curso)

);

Regras de negocio
O aluno deve estar cadastrdo
O curso deve estar cadastrado
O valor pago não pode ser negativo
O aluno nao pode ser matriculado duas vezes no mesmo curso
O curso deve possuir vagas disponíveis
Ao realizar uma matrícula válida, diminuir uma vaga disponível
Consultar alunos matriculados em um curso
Consultar cursos de um aluno.