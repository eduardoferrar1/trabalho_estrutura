package repository;

import database.ConnectionFactory;
import model.Aluno;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AlunoRepository {

    public void salvar(Aluno aluno) {

        String sql = "INSERT INTO aluno(nome,email,telefone) VALUES(?,?,?)";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, aluno.getNome());
            stmt.setString(2, aluno.getEmail());
            stmt.setString(3, aluno.getTelefone());

            stmt.executeUpdate();

            System.out.println("Aluno cadastrado!");

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public List<Aluno> listar() {

        List<Aluno> alunos = new ArrayList<>();

        String sql = "SELECT * FROM aluno";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {

                Aluno aluno = new Aluno();

                aluno.setId(rs.getInt("id"));
                aluno.setNome(rs.getString("nome"));
                aluno.setEmail(rs.getString("email"));
                aluno.setTelefone(rs.getString("telefone"));

                alunos.add(aluno);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return alunos;

    }

    public Aluno buscarPorId(int id) {

        String sql = "SELECT * FROM aluno WHERE id=?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                Aluno aluno = new Aluno();

                aluno.setId(rs.getInt("id"));
                aluno.setNome(rs.getString("nome"));
                aluno.setEmail(rs.getString("email"));
                aluno.setTelefone(rs.getString("telefone"));

                return aluno;

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;

    }

    public void atualizar(Aluno aluno) {

        String sql = "UPDATE aluno SET nome=?, email=?, telefone=? WHERE id=?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, aluno.getNome());
            stmt.setString(2, aluno.getEmail());
            stmt.setString(3, aluno.getTelefone());
            stmt.setInt(4, aluno.getId());

            stmt.executeUpdate();

            System.out.println("Aluno atualizado!");

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void excluir(int id) {

        String sql = "DELETE FROM aluno WHERE id=?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);

            stmt.executeUpdate();

            System.out.println("Aluno removido!");

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

}