package repository;

import database.ConnectionFactory;
import model.Matricula;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class MatriculaRepository {

    public void salvar(Matricula matricula){

        String sql="INSERT INTO matricula(id_aluno,id_curso,data_matricula,valor) VALUES(?,?,?,?)";

        try(Connection conn= ConnectionFactory.getConnection();
            PreparedStatement stmt=conn.prepareStatement(sql)){

            stmt.setInt(1,matricula.getIdAluno());
            stmt.setInt(2,matricula.getIdCurso());
            stmt.setDate(3,java.sql.Date.valueOf(matricula.getDataMatricula()));
            stmt.setDouble(4,matricula.getValor());

            stmt.executeUpdate();

            System.out.println("Matrícula realizada!");

        }catch(SQLException e){
            e.printStackTrace();
        }

    }

}
public boolean existeMatricula(int idAluno, int idCurso){

    String sql = "SELECT * FROM matricula WHERE id_aluno=? AND id_curso=?";

    try(Connection conn = ConnectionFactory.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql)){

        stmt.setInt(1,idAluno);
        stmt.setInt(2,idCurso);

        ResultSet rs = stmt.executeQuery();

        return rs.next();

    }catch(SQLException e){
        e.printStackTrace();
    }

    return false;
}
public void listarAlunosCurso(int idCurso){

    String sql = """
            SELECT a.nome
            FROM aluno a
            INNER JOIN matricula m
            ON a.id = m.id_aluno
            WHERE m.id_curso=?
            """;

    try(Connection conn = ConnectionFactory.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql)){

        stmt.setInt(1,idCurso);

        ResultSet rs = stmt.executeQuery();

        System.out.println("\nAlunos do curso:");

        while(rs.next()){

            System.out.println(rs.getString("nome"));

        }

    }catch(SQLException e){

        e.printStackTrace();

    }

}
public void listarCursosAluno(int idAluno){

    String sql = """
            SELECT c.nome
            FROM curso c
            INNER JOIN matricula m
            ON c.id=m.id_curso
            WHERE m.id_aluno=?
            """;

    try(Connection conn=ConnectionFactory.getConnection();
        PreparedStatement stmt=conn.prepareStatement(sql)){

        stmt.setInt(1,idAluno);

        ResultSet rs=stmt.executeQuery();

        System.out.println("\nCursos do aluno:");

        while(rs.next()){

            System.out.println(rs.getString("nome"));

        }

    }catch(SQLException e){

        e.printStackTrace();

    }

}