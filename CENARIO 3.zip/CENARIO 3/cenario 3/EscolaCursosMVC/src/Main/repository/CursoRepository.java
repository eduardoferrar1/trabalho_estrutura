package repository;

import database.ConnectionFactory;
import model.Curso;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CursoRepository {

    public void salvar(Curso curso){

        String sql = "INSERT INTO curso(nome,descricao,carga_horaria,vagas_totais,vagas_disponiveis) VALUES(?,?,?,?,?)";

        try(Connection conn = ConnectionFactory.getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql)){

            stmt.setString(1, curso.getNome());
            stmt.setString(2, curso.getDescricao());
            stmt.setInt(3, curso.getCargaHoraria());
            stmt.setInt(4, curso.getVagasTotais());
            stmt.setInt(5, curso.getVagasDisponiveis());

            stmt.executeUpdate();

            System.out.println("Curso cadastrado!");

        }catch(SQLException e){
            e.printStackTrace();
        }

    }

    public Curso buscarPorId(int id){

        String sql="SELECT * FROM curso WHERE id=?";

        try(Connection conn=ConnectionFactory.getConnection();
            PreparedStatement stmt=conn.prepareStatement(sql)){

            stmt.setInt(1,id);

            ResultSet rs=stmt.executeQuery();

            if(rs.next()){

                Curso curso=new Curso();

                curso.setId(rs.getInt("id"));
                curso.setNome(rs.getString("nome"));
                curso.setDescricao(rs.getString("descricao"));
                curso.setCargaHoraria(rs.getInt("carga_horaria"));
                curso.setVagasTotais(rs.getInt("vagas_totais"));
                curso.setVagasDisponiveis(rs.getInt("vagas_disponiveis"));

                return curso;

            }

        }catch(SQLException e){
            e.printStackTrace();
        }

        return null;

    }

    public List<Curso> listar(){

        List<Curso> cursos=new ArrayList<>();

        String sql="SELECT * FROM curso";

        try(Connection conn=ConnectionFactory.getConnection();
            PreparedStatement stmt=conn.prepareStatement(sql);
            ResultSet rs=stmt.executeQuery()){

            while(rs.next()){

                Curso curso=new Curso();

                curso.setId(rs.getInt("id"));
                curso.setNome(rs.getString("nome"));
                curso.setDescricao(rs.getString("descricao"));
                curso.setCargaHoraria(rs.getInt("carga_horaria"));
                curso.setVagasTotais(rs.getInt("vagas_totais"));
                curso.setVagasDisponiveis(rs.getInt("vagas_disponiveis"));

                cursos.add(curso);

            }

        }catch(SQLException e){
            e.printStackTrace();
        }

        return cursos;

    }

}
public void atualizarVagas(Curso curso){

    String sql = "UPDATE curso SET vagas_disponiveis=? WHERE id=?";

    try(Connection conn = ConnectionFactory.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql)){

        stmt.setInt(1, curso.getVagasDisponiveis());
        stmt.setInt(2, curso.getId());

        stmt.executeUpdate();

    }catch(SQLException e){
        e.printStackTrace();
    }

}