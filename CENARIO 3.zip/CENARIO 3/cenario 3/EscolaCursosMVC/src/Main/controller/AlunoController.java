package controller;

import model.Aluno;
import repository.AlunoRepository;

public class AlunoController {

    private AlunoRepository repository = new AlunoRepository();

    public void cadastrar(Aluno aluno){

        repository.salvar(aluno);

    }

}