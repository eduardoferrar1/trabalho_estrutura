package controller;

import model.Curso;
import repository.CursoRepository;

public class CursoController {

    private CursoRepository repository = new CursoRepository();

    public void cadastrar(Curso curso){

        repository.salvar(curso);

    }

}