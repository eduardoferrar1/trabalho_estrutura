package controller;

import service.MatriculaService;

public class MatriculaController {

    private MatriculaService service = new MatriculaService();

    public void matricular(int idAluno,int idCurso,double valor){

        service.matricular(idAluno,idCurso,valor);

    }

}