public class Matricula {

    private Integer id;
    private Integer idAluno;
    private Integer idCurso;
    private LocalDate dataMatricula;
    private Double valor;

}package model;

import java.time.LocalDate;

public class Matricula {

    private Integer id;
    private Integer idAluno;
    private Integer idCurso;
    private LocalDate dataMatricula;
    private Double valor;

    public Matricula() {
    }

    public Matricula(Integer idAluno,
                     Integer idCurso,
                     LocalDate dataMatricula,
                     Double valor) {

        this.idAluno = idAluno;
        this.idCurso = idCurso;
        this.dataMatricula = dataMatricula;
        this.valor = valor;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIdAluno() {
        return idAluno;
    }

    public void setIdAluno(Integer idAluno) {
        this.idAluno = idAluno;
    }

    public Integer getIdCurso() {
        return idCurso;
    }

    public void setIdCurso(Integer idCurso) {
        this.idCurso = idCurso;
    }

    public LocalDate getDataMatricula() {
        return dataMatricula;
    }

    public void setDataMatricula(LocalDate dataMatricula) {
        this.dataMatricula = dataMatricula;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }
}