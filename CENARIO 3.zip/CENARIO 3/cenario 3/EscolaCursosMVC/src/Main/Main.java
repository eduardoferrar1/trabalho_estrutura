import controller.AlunoController;
import controller.CursoController;
import controller.MatriculaController;
import model.Aluno;
import model.Curso;
import repository.MatriculaRepository

public class Main {

    public static void main(String[] args) {

        AlunoController alunoController = new AlunoController();
        CursoController cursoController = new CursoController();
        MatriculaController matriculaController = new MatriculaController();

        Aluno aluno1 = new Aluno(
                "João Silva",
                "joao@email.com",
                "(44)99999-1111"
        );

        alunoController.cadastrar(aluno1);

        Aluno aluno2 = new Aluno(
                "Maria Souza",
                "maria@email.com",
                "(44)99999-2222"
        );

        alunoController.cadastrar(aluno2);

        Curso cursoJava = new Curso(
                "Java",
                "Curso de Java Básico",
                80,
                2,
                2
        );

        cursoController.cadastrar(cursoJava);

        Curso cursoSQL = new Curso(
                "PostgreSQL",
                "Banco de Dados",
                40,
                1,
                1
        );

        cursoController.cadastrar(cursoSQL);

        matriculaController.matricular(1,1,500);
        matriculaController.matricular(2,1,500);

        matriculaController.matricular(1,1,500);

        matriculaController.matricular(2,1,500);

        MatriculaRepository repository = new MatriculaRepository();

        repository.listarAlunosCurso(1);
        repository.listarCursosAluno(1);
    }
}