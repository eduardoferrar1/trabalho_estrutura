package service;

import model.Aluno;
import model.Curso;
import model.Matricula;
import repository.AlunoRepository;
import repository.CursoRepository;
import repository.MatriculaRepository;

import java.time.LocalDate;

public class MatriculaService {

    private AlunoRepository alunoRepository = new AlunoRepository();
    private CursoRepository cursoRepository = new CursoRepository();
    private MatriculaRepository matriculaRepository = new MatriculaRepository();

    public void matricular(int idAluno, int idCurso, double valor){

        Aluno aluno = alunoRepository.buscarPorId(idAluno);

        if(aluno == null){

            System.out.println("Aluno não encontrado.");
            return;

        }

        Curso curso = cursoRepository.buscarPorId(idCurso);

        if(curso == null){

            System.out.println("Curso não encontrado.");
            return;

        }

        if(valor < 0){

            System.out.println("Valor inválido.");
            return;

        }

        if(curso.getVagasDisponiveis() <= 0){

            System.out.println("Curso sem vagas.");
            return;

        }

        if(matriculaRepository.existeMatricula(idAluno,idCurso)){

            System.out.println("Aluno já matriculado neste curso.");
            return;

        }

        Matricula matricula = new Matricula(
                idAluno,
                idCurso,
                LocalDate.now(),
                valor
        );

        matriculaRepository.salvar(matricula);

        curso.setVagasDisponiveis(
                curso.getVagasDisponiveis()-1
        );

        cursoRepository.atualizarVagas(curso);

        System.out.println("Matrícula realizada com sucesso!");

    }

}