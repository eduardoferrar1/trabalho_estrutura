public void matricular(Matricula matricula){

    if(matricula.getValor() < 0){

        throw new RuntimeException("Valor inválido");

    }
}